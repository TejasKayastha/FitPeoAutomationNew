package StepDefinitions;

import java.util.concurrent.TimeUnit;

import org.junit.Assert;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;

import io.cucumber.java.en.*;
import utils.DriverManager;
import utils.ScreenshotUtil;

public class LoginDemoSteps {

	String xRevanueCalculatePage = "//div[contains(text(),'Revenue Calculator')]";
	String xSlider = "//h4[text()='Medicare Eligible Patients']";
	String xSlidingBall = "//h4[text()='Medicare Eligible Patients']";
	String xValueBox = "//input[@id=':r0:']";

	WebDriver driver = DriverManager.getDriver();

	
	@And("sleep for {int} seconds")
	public void sleep(Integer seconds) {
		driver.manage().timeouts().implicitlyWait(seconds, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
	}
	
	@Given("Open the web browser and navigate to FitPeo Homepage")
	public void open_the_web_browser_and_navigate_to_FitPeo_Homepage() {
		System.out.println("browser is open");

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		driver.manage().timeouts().pageLoadTimeout(40, TimeUnit.SECONDS);
		driver.manage().window().maximize();
		driver.navigate().to("https://www.fitpeo.com/");
		System.out.println("URL Launched");
		ScreenshotUtil.takeScreenshot(driver, "HomePage");
	}

	@And("From the homepage navigate to the Revenue Calculator Page")
	public void from_the_homepage_navigate_to_the_Revenue_Calculator_Page() throws InterruptedException {
		WebElement revenue = driver.findElement(By.xpath(xRevanueCalculatePage));
		revenue.isDisplayed();
		revenue.click();
		Thread.sleep(5000);
		ScreenshotUtil.takeScreenshot(driver, "RevenueCalculatorPage");
	}

	@And("Scroll down the page until the revenue calculator slider is visible")
	public void scroll_down_the_page_until_the_revenue_calculator_slider_is_visible() {
		WebElement slider = driver.findElement(By.xpath(xSlider));
//		String xSlidingBall = "//h4[text()='Medicare Eligible Patients']//following::input[@type='range']";
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true)", slider);
//		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center'});", slider);
//		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center'});", xSlidingBall);

		slider.isDisplayed();
		ScreenshotUtil.takeScreenshot(driver, "CalculatorSliderIsVisible");
	}

	@And("Adjust the slider to set its value to {int}")
	public void adjust_the_slider_to_set_its_value_to(Integer int1) {

		String xSlidingBall = "//h4[text()='Medicare Eligible Patients']//following::input[@type='range']";
		String xValueBox = "//input[@id=':r0:']";
		
		WebElement slider = driver.findElement(By.xpath(xSlidingBall)); 
		WebElement valueBox = driver.findElement(By.xpath(xValueBox));
		
		int targetValue = int1;
		int currentValue = Integer.parseInt(valueBox.getAttribute("value"));
		
		while (currentValue != targetValue) {
			if (currentValue < targetValue) {
				slider.sendKeys(Keys.ARROW_RIGHT); // Increase the slider value
			} else {
				slider.sendKeys(Keys.ARROW_LEFT); // Decrease the slider value
			}
			currentValue = Integer.parseInt(valueBox.getAttribute("value"));
		}
		
		ScreenshotUtil.takeScreenshot(driver, "SliderAdjustedToGivenValue"+int1);

		
	}
	
	@And("Enter the value {int} in the text field and Check Slider")
	public void enter_the_value_in_the_text_field_and_Check_Slider(Integer int1) {
	   
		String xValueBox = "//input[@id=':r0:']";
		String xSlider = "//h4[text()='Medicare Eligible Patients']";
		
		WebElement textBox = driver.findElement(By.xpath(xValueBox));
				
		textBox.isDisplayed();
		textBox.click();
		textBox.clear();
		String revisedValue = int1.toString();
		textBox.sendKeys(revisedValue);
		
		ScreenshotUtil.takeScreenshot(driver, "EnteredRevisedvalueInTextBox" + revisedValue );
	}
	
	@Given("Ensure that when the value {int} is entered in the text field the slider position is updated to reflect the value {int}")
	public void ensure_that_when_the_value_is_entered_in_the_text_field_the_slider_position_is_updated_to_reflect_the_value(Integer int1, Integer int2) {
	
		String xValueBox = "//input[@id=':r0:']";
		String xSlidingBall = "//h4[text()='Medicare Eligible Patients']//following::input[@type='range']";
		
		WebElement textBox = driver.findElement(By.xpath(xValueBox));
		WebElement slider = driver.findElement(By.xpath(xSlidingBall));
		
//		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", textBox);
		
		textBox.isDisplayed();
		
		((JavascriptExecutor) driver).executeScript("arguments[0].value = '';", textBox);
		((JavascriptExecutor) driver).executeScript("arguments[0].value = arguments[1];", textBox, int1.toString());
		((JavascriptExecutor) driver).executeScript("arguments[0].dispatchEvent(new Event('input'));", textBox);
		
		ScreenshotUtil.takeScreenshot(driver, "SliderPositionAfterEnteredRevisedvalueInTextBox" );
		
		int actualSliderValue = Integer.parseInt(slider.getAttribute("value"));
		assert actualSliderValue == int2 : "Expected slider value to be " + int2 + " but was " + actualSliderValue;
	}
	
	
	@And("Scroll down further and select the checkboxes for {string}, {string}, {string}, {string}")
	public void scroll_down_further_and_select_the_checkboxes_for(String code1, String code2, String code3, String code4) {
	    
		String[] cptCodes = {code1, code2, code3, code4};
		int checkBoxCount=0;
		for (String code : cptCodes) {
			checkBoxCount++;
			String xpath = "//*[text()='" + code + "']";
			WebElement cptElement = driver.findElement(By.xpath(xpath));
			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center'});", cptElement);
			
			try { 
				Thread.sleep(5000); 
				} catch (InterruptedException e) { 
					e.printStackTrace(); 
					}
			
			if(checkBoxCount==4)
				checkBoxCount = checkBoxCount+4;
			
//			WebElement parentElement = cptElement.findElement(By.xpath("./ancestor::*[contains(@class, 'MuiFormControlLabel-root')]"));
			WebElement checkbox = driver.findElement(By.xpath("(//span[@class='MuiTypography-root MuiTypography-body1 MuiFormControlLabel-label css-1s3unkt'])["+checkBoxCount+"]"));
			
			if (checkbox.isDisplayed() && !checkbox.isSelected()) { 
				checkbox.click(); 
				ScreenshotUtil.takeScreenshot(driver, "CheckBoxClickedFor"+ code);
				}
			
		}		
	}
	
//	@And("Scroll down further and select the checkboxes for {string}, {string}, {string}, {string}")
//	public void scroll_down_further_and_select_the_checkboxes_for(String code1, String code2, String code3, String code4) {
//	    
//		String[] cptCodes = {code1, code2, code3, code4};
//		
//		for (String code : cptCodes) {
//			String xpath = "//*[text()='" + code + "']";
//			WebElement checkbox = driver.findElement(By.xpath(xpath));
////			((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView(true);", checkbox);
//			((JavascriptExecutor) driver).executeScript("window.scrollTo(0, arguments[0].getBoundingClientRect().top + window.pageYOffset - 100);", checkbox);
//			
//			try { 
//				Thread.sleep(5000);
//				} catch (InterruptedException e)  	
//			{ 
//					e.printStackTrace(); 
//			
//			}
//			
////			if (checkbox.isDisplayed() && !checkbox.isSelected()) { 
////				checkbox.click();
////				}
//			
//		}		
//	}
//	
	
	@And("Validate Total Recurring Reimbursement")
	public void validate_Total_Recurring_Reimbursement() {

		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		
		String xTotalRecurringReimbursement = "//p[text()='Total Recurring Reimbursement for all Patients Per Month:']";
		WebElement reimbursement = driver.findElement(By.xpath(xTotalRecurringReimbursement));
		((JavascriptExecutor) driver).executeScript("arguments[0].scrollIntoView({block: 'center'});", reimbursement);
		String reimbursementAmount = reimbursement.getText();
		System.out.println(reimbursementAmount);
		
		ScreenshotUtil.takeScreenshot(driver, "TotalRecurringReimbursement");
		
	}
	
	@And("displaying Total Recurring Reimbursement for all Patients Per Month shows the value {string}")
	public void displaying_Total_Recurring_Reimbursement_for_all_Patients_Per_Month_shows_the_value(String amount) {
	   
		driver.manage().timeouts().implicitlyWait(40, TimeUnit.SECONDS);
		
		String xTotalRecurringReimbursement = "//p[text()='Total Recurring Reimbursement for all Patients Per Month:']";
		WebElement reimbursement = driver.findElement(By.xpath(xTotalRecurringReimbursement));
		String reimbursementAmount = reimbursement.getText();
		System.out.println(reimbursementAmount);
		System.out.println(amount);
		boolean isAmountCorrrect = reimbursementAmount.contains(amount);
		System.out.println("isAmountCorrrect : " + isAmountCorrrect);
		
	}

	
	
}
