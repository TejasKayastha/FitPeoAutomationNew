package utils;

import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;

public class ScreenshotUtil {

    public static void takeScreenshot(WebDriver driver, String screenshotName) {
        // Create a timestamp for unique screenshot names
        String timestamp = new SimpleDateFormat("yyyyMMddHHmmss").format(new Date());
        // Create the screenshot file name
        String fileName = timestamp + "_" + screenshotName + ".png";

        // Capture the screenshot
        File srcFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        // Specify the destination path for the screenshot
        String projectPath = System.getProperty("user.dir");
        File destFile = new File(projectPath + "/ScreenShots/" + fileName);

        ///
//        String userHome = System.getProperty("user.dir");
//        String newFolderPath = userHome + File.separator + timestamp;
//        File newFolder = new File(newFolderPath);
//        boolean created = newFolder.mkdirs();
        
        ///
        
        
        // Copy the screenshot to the destination path
        try {
            FileUtils.copyFile(srcFile, destFile);
            System.out.println("Screenshot saved to: " + destFile.getAbsolutePath());
        } catch (IOException e) {
            e.printStackTrace();
            System.out.println("Failed to save screenshot: " + e.getMessage());
        }
    }
}
